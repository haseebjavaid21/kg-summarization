There are three folders consisting of the summaries of three implementations:

1. with real world(In folder named:output_rw,omitting all non-real world entities), 
2. with some non-real world entities (In folder named:output_srw,here only few non-world entities are omitted , some are kept,here the benchmark results are closer to the previous),
3. without real world considerations(In folder named:output_nrw,contains most number of non-real world entities i'e, none of them are omitted)):

The folders themselves consists of folders of results for entities each consisting of top_5 and top_10 summaries.

P.S, In real world entity implementation,there are few triples (in the real world entities consideration) where some values such as "<http://dbpedia.org/resource/Category:Radio_stations_in_Victoria>"  or properties such as "<http://dbpedia.org/ontology/abstract>" exist and are considered. These are kept inspite that they're not real world entities because they do have some meaning to them and convey something relevant about the target entity.

Finally, These contain entities as seen in S4.txt